#ifndef _GLOBAL_H_
#define _GLOBAL_H_

#include "main.h"

#define	false	0x00
#define	true	0x01

typedef enum {msgNone,msgTimeOut,
	msgDcOutOK,msgDcInOK,msgDcInTimeOut,msgDcInOver,
	msgAcOutOK,msgAcInOK,msgAcInNone,msgAcInTimeOut,
	msgKeyCmd} mssg;
typedef enum {destroy,ready,excute,block} sv;
typedef enum {mode_none,
	mAC_TDRE_T,mAC_TDRE_F,mAC_RDRF_T,mAC_RDRF_F,
	mDC_TDRE_T,mDC_TDRE_F,mDC_RDRF_T,mDC_RDRF_F,
	mMa_Normal,mMa_QiangZi,mMa_GuZangJianCe,
	mLCD_PowerOn,mLCD_Off,mLCD_Normal,mLCD_LL,mLCD_HH,mLCD_GuZangJianCe,
	mKey_Normal,
	mKeyProces_Normal} mv;
struct tagpcb
{ 
sv status;
mv mode;
unsigned int step;
unsigned int clk;
mssg message;
};
typedef struct tagpcb pcb_def;

extern pcb_def pcb_clockchain;
extern pcb_def pcb_AC_Out;
extern pcb_def pcb_AC_In;
extern pcb_def pcb_DC_Out;
extern pcb_def pcb_DC_In;
extern pcb_def pcb_manager;
extern pcb_def pcb_lcd;
extern pcb_def pcb_keyread;
extern pcb_def pcb_keyprocess;


#endif

