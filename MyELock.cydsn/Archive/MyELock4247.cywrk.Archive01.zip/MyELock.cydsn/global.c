#include "global.h"

#define zzndebug

pcb_def pcb_clockchain;
pcb_def pcb_AC_Out;
pcb_def pcb_AC_In;
pcb_def pcb_DC_Out;
pcb_def pcb_DC_In;
pcb_def pcb_manager;
pcb_def pcb_lcd;
pcb_def pcb_keyread;
pcb_def pcb_keyprocess;

void Create(pcb_def * ppcb,unsigned char mode,unsigned char mesg)
{
	if(ppcb -> status == destroy)
	{
		ppcb -> mode = mode;		
		ppcb -> clk = 0;
		ppcb -> step = 0;
		ppcb -> status = ready;
		ppcb -> message = mesg;
	}
	else
	{
		while (1);
	}
}
void Block(pcb_def * ppcb,unsigned int clk)
{
	if(ppcb -> status != destroy)
	{
		ppcb -> status = block;
		ppcb -> clk = clk;
		ppcb -> message = msgNone;
	}
}

void Wakeup(pcb_def * ppcb,unsigned char mesg)
{
	if(ppcb -> status == block)
	{
		ppcb -> status = ready;
		ppcb -> clk = 0;		
		ppcb -> message = mesg;
	}
	else
	{
		while (1);
	}
}
void Destroy(pcb_def * ppcb)
{
	ppcb -> clk = 0;
	ppcb -> mode = mode_none;
	ppcb -> step = 0;
	ppcb -> status = destroy;
	ppcb -> message = msgNone;	
}

void InitArray(unsigned char *p,unsigned char len,unsigned char dat)
{
	unsigned char i;
	for(i=0;i<len;i++)
	{
		*p=dat;
		p++;
	}
}

void copyArray(unsigned char *pSource,unsigned char *pDest,unsigned char j)
{
	unsigned char i;
	for(i=0;i<j;i++)
	{
		*pDest = *pSource;
		pSource++;
		pDest++;
	}
}

